<!DOCTYPE html>
<html>
<head>
	<title>Liste des étudiants par module</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<h1>Gestion d'absence</h1>
	</header>
	<nav>
		<ul>
			<li><a href="inscription_module.html">Inscription des modules</a></li>
			<li><a href="liste_etudiants_par_module.html">Liste des étudiants par module</a></li>
			<li><a href="liste_etudiants_par_module.php">Liste des étudiants par module</a></li>
			<li><a href="bilan_absence.php">Bilan d'absence</a></li>
		</ul>
	</nav>
	<main>
		<h2>Liste des étudiants par module</h2>
		<form method="post" action="">
			<label for="module">Sélectionnez un module :</label>
			<select name="module" id="module">
				<?php
					// Connexion à la base de données
					$bdd = new PDO('mysql:host=localhost;dbname=gestion_absence', 'utilisateur', 'motdepasse');

					// Récupération de la liste des modules
					$requete = $bdd->query('SELECT * FROM modules ORDER BY id');
					$modules = $requete->fetchAll();

					// Affichage de la liste déroulante des modules
					foreach ($modules as $module) {
						echo '<option value="' . $module['id'] . '">' . $module['id'] . ' - ' . $module['intitule'] . '</option>';
					}

					// Fermeture de la requête
					$requete->closeCursor();
				?>
			</select>
			<input type="submit" value="Afficher">
		</form>
		<?php
			// Vérification de l'existence de la variable $_POST['module']
			if (isset($_POST['module'])) {
				// Récupération de la liste des étudiants pour le module sélectionné
				$requete = $bdd->prepare('SELECT * FROM etudiants WHERE module_id = :module_id ORDER BY nom, prenom');
				$requete->execute(array('module_id' => $_POST['module']));
				$etudiants = $requete->fetchAll();

				// Affichage de la liste des étudiants
				if (count($etudiants) > 0) {
					echo '<h3>Liste des étudiants :</h3>';
					echo '<ul>';
					foreach ($etudiants as $etudiant) {
						echo '<li>' . $etudiant['nom'] . ' ' . $etudiant['prenom'] . '</li>';
					}
					echo '</ul>';
				} else {
					echo '<p>Aucun étudiant inscrit dans ce module.</p>';
				}

				// Fermeture de la requête
				$requete->closeCursor();
			}
		?>
	</main>
	<footer>
		<p>Réalisé par [votre nom]</p>
	</footer>
</body>
</html>
